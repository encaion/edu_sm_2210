list.files()
head()

install.packages("beepr")
library("beepr")
beep(2) # 마리오 동전소리ㅋㅋ
# 주석(comment)
# 주석은 코드 실행에 영향을 미치지 않음.

?beep

# 객체(object): 데이터를 담는 통
df = read.csv("iris_missing.csv")
head(df)
head(df, 2)
tail(df)
tail(df, 3)
df

write.csv(df, "write_csv_1.csv")
write.csv(df, "write_csv_2.csv", row.names = FALSE)

# TRUE: 참 또는 1
# FALSE: 거짓 또는 0

# = : 할당(assign) 연산자
df = read.csv("temp_sensor.csv")
head(df)

"감자" == "고구마" # 감자와 고구마가 같니?
"감자" != "고구마" # 감자와 고구마가 다르니?
# not equal
 
df_in  = df[df$location == "In", ]
df_out = df[df$location != "In", ]
write.csv(df_in,  "sensor_in.csv",  row.names = FALSE)
write.csv(df_out, "sensor_out.csv", row.names = FALSE)

aa = c(2, 4, 6, 8)
aa
aa[1] # aa 객체의 첫 번째 원소
aa[-1] # aa 객체의 첫 번째 원소를 제외한 나머지
aa[c(1, 3)] # aa 객체의 첫 번째, 세번째 원소
aa[c(TRUE, FALSE, TRUE, FALSE)]
aa[aa > 7]
aa[aa < 7]
aa[aa <= 7]
aa[aa >= 7]

df = data.frame(aa = 1:3,
                bb = c("a", "b", "c"))
df[c(1, 3), ]
df[c(TRUE, FALSE, TRUE), ]
df[df$aa != 2, ]
# df[ row , column ]
df[(df$aa == 3) | (df$bb == "c"), ]
# df 객체의 aa 변수가 3 "이거나" 
# df 객체의 bb 변수가 c 인 row

df[(df$aa == 3) & (df$bb == "c"), ]
# df 객체의 aa 변수가 3 "이면서" 
# df 객체의 bb 변수가 c 인 row

df = data.frame(aa = 1:3,
                bb = 3:5)
df
df[, "new_col"] = df$aa * df$bb
df
# 콤마 앞 또는 뒤를 비워두는 것은 
# 전체를 선택하는 것과 같다.
df[2, 3]


df = read.csv("temp_sensor.csv")
head(df, 2)
df[, "temp_100"] = df$temp * 100
head(df, 2)

25 / 5
27 / 5
27 %% 5 # 나머지
27 %/% 5 # 몫

c(12, 15, 17, 27) %/% 5
# unit test

df[, "temp_5d"] = df$temp %/% 5
head(df)

for(number in 1:3){
  print(number)
}

for(number in 1:3){
  print(number)
  Sys.sleep(2)
}

for(ss in c("a", "b", "d")){
  print(ss)
}

df_1 = data.frame(aa = letters[1:4],
                  bb = 1:4)
for(num in 1:4){
  df_1[num, "new_column"] = num * 2
  Sys.sleep(2)
  print(df_1)
}
df_1
# NA: Not Available. 즉, 결측치(missing)를 의미
#     엑셀로 따지면 비어있는 셀.

for(n in 1:65){
  cat(paste0("\r==== Progress: ", n, "/65 ===="))
  Sys.sleep(0.2)
}

paste0(1, 2, 3)
# paste0("1", "2", "3")
paste0("a", "b", "c")
paste0(c("a", "b", "c"))
paste0("sample_", 1:3)
paste0(c("a", "b", "c"), collapse = "")

paste(010, 1234, 5678, sep = "-")

round(12.345, 1)

for(n in 1:65){
  cat(paste0("\r==== Progress: ", n, "/65 (",
             round(n / 65 * 100, 1), "%) ===="))
  Sys.sleep(0.2)
}

# install.packages("lubridate")
# source("data_generator_folders_files.R")

file_list = list.files(path = "Item_19274_DB/",
                       recursive = TRUE,
                       full.names = TRUE)
head(file_list)

df_sub = read.csv("Item_19274_DB/2022-07-09/Item_promo_150.csv")
head(df_sub)

head(file_list)
length(file_list)

file_list2 = list.files(path = "Item_19274_DB/",
                        pattern = "Item",
                        recursive = TRUE,
                        full.names = TRUE)
head(file_list2)

df1 = read.csv(file_list2[1])
df2 = read.csv(file_list2[2])
df1
df2
nrow(df1) # number of rows, 행 개수
nrow(df2)
df_bind = rbind(df1, df2) # row binding
df_bind
nrow(df_bind)

df_bind = data.frame()
for(n in 1:length(file_list2)){
  df_sub = read.csv(file_list2[n])
  df_bind = rbind(df_bind, df_sub)
}
nrow(df_bind)

install.packages("data.table")
library("data.table")

# beep(2)
# beepr::beep(2)

setDTthreads(threads = 2)
getDTthreads()

dt_bike = fread("bike.csv")
head(dt_bike, 2)

df_bike = read.csv("bike.csv")
head(df_bike, 2)

aa = 1:3
class(aa)
class(df_bike)
class(dt_bike)

# install.packages("dplyr")
library("dplyr")
tb_bike = as_tibble(df_bike)
head(tb_bike, 2)
class(tb_bike)
