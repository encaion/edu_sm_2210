letters
LETTERS
c("a", "b", "c", "d")
head(letters)
?head
head(letters, 2)
head(x = letters, n = 2)
head(2, letters)
head(n = 2, x = letters)

for_list = c("a", "b", "c")
for(chr in for_list){
  print(chr)
}

as.character(123)
as.numeric("123")
as.numeric("aaa")
class(123)
class("a")
# typeof(123)

df_iris = iris
head(df_iris)
class(df_iris)

library("data.table")
dt_iris = as.data.table(df_iris)
head(dt_iris)
class(dt_iris)

df_iris2 = as.data.frame(dt_iris)
head(df_iris2)
class(df_iris2)

table(df_iris2$Species) # 원소 또는 조합 개수 세기
as.data.frame(table(df_iris2$Species))

colors()

install.packages("ggplot2")

df = data.frame(xx = 1:10,
                yy = c(1:4, 5:3, 6:8))
df
library("ggplot2")
ggplot(data = df, 
       mapping = aes(x = xx, y = yy)) + 
  geom_point()

# ggplot() + 
#   geom_point(df, aes(x = xx, y = yy))
ggplot() + 
  geom_point(aes(x = xx, y = yy), df)


ggplot(df, aes(xx, yy)) + 
  geom_point()

ggplot(df, aes(xx, yy)) + 
  geom_col()

ggplot(df, aes(xx, yy)) + 
  geom_line()


ggplot(df, aes(xx, yy)) + 
  geom_point(color = "#FFA500")

ggplot(df, aes(xx, yy)) + 
  geom_point(size = 10)

ggplot(df, aes(xx, yy)) + 
  geom_point(color = "red", size = 10)

ggplot(df, aes(xx, yy)) + 
  geom_point(size = 10, shape = 6)
ggplot(df, aes(xx, yy)) + 
  geom_point(size = 10, shape = "?")
ggplot(df, aes(xx, yy)) + 
  geom_point(size = 10, shape = "ㅋ")
ggplot(df, aes(xx, yy, color = yy)) + 
  geom_point(size = 10, shape = "★")

df = read.csv("temp_sensor.csv")
head(df, 2)

ggplot(data = df,
       aes(x = as.numeric(rownames(df)),
           y = temp)) + 
  geom_line()

library("lubridate")
df[, "tm"] = as_datetime(df$time_stamp,
                         format = "%d-%m-%Y %H:%M")
head(df, 2)
ggplot(data = df,
       aes(x = tm,
           y = temp)) + 
  geom_line()


df = data.frame(xx = 1:10,
                yy = c(1:4, 5:3, 6:8))

gg = ggplot(df, aes(xx, yy)) + 
  geom_point(size = 10, color = "red")
gg
# install.packages("plotly")
library("plotly")
ggplotly(gg)

d_t = "2022-10-18"
months(as.Date(d_t))
months(as.Date(d_t), abbreviate = TRUE)

month(d_t)

d_t2 = "2022년 10월 18일"
as.Date(d_t2)
as_date(d_t2)
as_date(d_t2, format = "%Y년 %m월 %d일")
# %Y: 4자리수 연도
# %m: 월
# %d: 일
# %H: 24시간제 시간
# %M: 분
# %s: 초
# YYYY-mm-dd HH:MM:ss

seq(from = as_date("2022-10-01"),
    to = as_date("2022-10-31"),
    by = "day")
seq(from = as_date("2022-10-01"),
    to = as_date("2022-10-31"),
    by = "2 day")

vec_d = seq(from = as_date("2022-02-01"),
            to = as_date("2023-01-01"),
            by = "month") - 1 # 각 월의 말일
vec_d
year(vec_d)
month(vec_d)
day(vec_d)
wday(vec_d)
wday(vec_d, week_start = 1) # 월요일이 1
wday(vec_d, week_start = 1, label = TRUE)
wday(vec_d, week_start = 1, label = TRUE, abbr = FALSE)

ts(vec_d)

install.packages("TTR")
library("TTR")
df = read.csv("seoul_subway.csv", fileEncoding = "UTF-8")
df_sub = df[df$역명 == "종각", ]
df_sub[, "사용일자"] = as_date(as.character(df_sub$사용일자))
ggplot(data = df_sub,
       aes(x = 사용일자, y = 승차총승객수)) + 
  geom_line() + 
  scale_x_date(date_labels = "%Y-%m",
               date_breaks = "month")

# SMA(df_sub$승차총승객수, n = 7)
df_sub[, "ma_7" ] = SMA(df_sub$승차총승객수, n = 7)
df_sub[, "ma_30"] = SMA(df_sub$승차총승객수, n = 30)
tail(df_sub, 4)
head(df_sub, 10)

df_sub2 = df_sub[df_sub$사용일자 >= "2020-06-01", ]
df_sub2 = df_sub2[, c("사용일자", "승차총승객수",
                      "ma_7", "ma_30")]
colnames(df_sub2)[1:2] = c("date", "on") # 변수명 바꾸기
head(df_sub2)

# write.csv(df_sub2, "melt_sample_before.csv", row.names = FALSE)

library("reshape2")
df_sub2_melt = melt(data = df_sub2,
                    id.vars = "date")
df_sub2_melt = df_sub2_melt[order(df_sub2_melt$date, 
                                  df_sub2_melt$variable), ]
head(df_sub2_melt)

nrow(df_sub2) # wide form(fat matrix)
nrow(df_sub2_melt) # long form(tall matrix)

# write.csv(df_sub2_melt, "melt_sample_after.csv", row.names = FALSE)

ggplot(data = df_sub2_melt,
       aes(x = date, y = value, 
           group = variable,
           color = variable)) + 
  geom_line()


# install.packages("caret")
library("caret")
df_dia = read.csv("diamonds.csv")
df_dia = df_dia[, -c(2, 3, 4)] # 특정 인덱스를 제외하고~~~
head(df_dia, 2)

sapply(df_dia, FUN = "min") # 각 column의 최소값
sapply(df_dia, FUN = "max") # 각 column의 최대값
# FUN은 function 의 첫 세글자.

model_nor = preProcess(df_dia, method = "range") # 규칙 학습
model_nor$ranges
df_dia_nor = predict(model_nor, df_dia) # 규칙 적용
head(df_dia_nor, 2)
sapply(df_dia_nor, FUN = "min")
sapply(df_dia_nor, FUN = "max")

#### k-NN ####
library("caret")
df_dia = read.csv("diamonds.csv")
vec_price = df_dia$price
df_dia = df_dia[, -c(2:4, 7)]

model_nor = preProcess(df_dia, method = "range")
df_dia_nor = predict(model_nor, df_dia)

set.seed(123)
id_test = sample(1:nrow(df_dia), size = 5000, replace = FALSE)
head(id_test)

vec_price_train = vec_price[-id_test]
vec_price_test  = vec_price[ id_test]
df_dia_nor_train = df_dia_nor[-id_test, ]
df_dia_nor_test  = df_dia_nor[ id_test, ]
nrow(df_dia_nor_train)
nrow(df_dia_nor_test)

model_knn = knnreg(x = df_dia_nor_train,
                   y = vec_price_train,
                   k = 5)
pred_knn = predict(model_knn, df_dia_nor_test)
head(pred_knn)

head(df_dia_nor_test, 2)

df_knn_score = data.frame(y_true = vec_price_test,
                          y_pred = pred_knn)
head(df_knn_score)
df_knn_score[, "error"] = df_knn_score$y_true - df_knn_score$y_pred
head(df_knn_score)

# install.packages("Metrics")
library("Metrics")
rmse(actual = df_knn_score$y_true,
     predicted = df_knn_score$y_pred)
