?head

df = airquality

aggregate(data = df,
          Wind ~ Month, 
          FUN = "mean")

list.files()
df_sub = read.csv("seoul_subway.csv")
head(df_sub, 2)
unique(df_sub$노선명)
# Q1. 2호선의 역별 하차총승객수의 평균을 구하시오.
df_sub2 = df_sub[df_sub$노선명 == "2호선", ]
aggregate(data = df_sub2, 하차총승객수 ~ 역명,
          FUN = "mean")

# Q2. 3호선과 4호선을 필터링 하고
#     해당 호선별 역별 승차총승객수의 평균을 구하시오.
df_sub34 = df_sub[(df_sub$노선명 == "3호선") | (df_sub$노선명 == "4호선"), ]
df_sub34 = df_sub[df_sub$노선명 %in% c("3호선", "4호선"), ]
unique(df_sub34$노선명)

aggregate(data = df_sub34, 승차총승객수 ~ 노선명 + 역명, FUN = "mean")


df_a = data.frame(col1 = c(100, 200, 300),
                  col2 = c(400, 500, 600))
apply(df_a, MARGIN = 1, FUN = "sum")
rowSums(df_a)

df_a[, "sum"] = apply(df_a, MARGIN = 1, FUN = "sum")
df_a

df_score = read.csv("class_scores.csv")
# Q. 과목별 최소값, 최대값, 평균값을 산출하고
#    해당 값을 하나의 데이터프레임 객체에 정리하시오.
# apply(df_score, MARGIN = 2, FUN = "min")
df_score[1:3, 5:9]
apply(df_score[1:3, 5:9], MARGIN = 2, FUN = "min")

stat_1 = apply(df_score[, 5:9], MARGIN = 2, FUN = "min")
stat_2 = apply(df_score[, 5:9], MARGIN = 2, FUN = "max")
stat_3 = apply(df_score[, 5:9], MARGIN = 2, FUN = "mean")
stat_3

colnames(df_score)[5:9]

df_stat = data.frame(subject = colnames(df_score)[5:9],
                     min = stat_1,
                     max = stat_2,
                     mean = stat_3)
rownames(df_stat) = NULL # 꼭 할 필요는 없음
df_stat

# install.packages("psych")
library("psych")
df = read.csv("diamonds.csv")
describe(df)

library("remotes")
install_github("https://github.com/pablo14/funModeling")
library("funModeling")
df_status(df)
plot_num(df)

plot(x = 1:5, y = 1:5,
     pch = "ㅋ", col = "#FF0000")

colors()

install.packages("plotly")
install.packages("ggplot2")
library("plotly")
library("ggplot2")
gg = qplot(1:10, 1:10, size = 5,
           color = "#FFAACC")
ggplotly(gg)


qplot(1, 1)

e <- ggplot(mpg, aes(cty, hwy))
e + geom_point() 

set.seed(123)
df = data.frame(xx = 1:10,
                yy = sample(1:10, 10))

ggplot(data = df, aes(x = xx, y = yy)) +
  geom_point()
ggplot(data = df, aes(x = xx, y = yy)) +
  geom_line()
ggplot(data = df, aes(x = xx, y = yy)) +
  geom_col()

ggplot(data = df, aes(x = xx, y = yy)) +
  geom_bar(stat = "identity")

ggplot() +
  geom_point(data = df, 
             aes(x = xx, y = yy))

ggplot(data = iris,
       mapping = aes(x = Sepal.Length,
                     y = Petal.Width)) + 
  geom_point(color = "#FF0000")

ggplot(data = iris,
       mapping = aes(x = Sepal.Length,
                     y = Petal.Width)) + 
  geom_point(color = "#F30AF7",
             size = 5, 
             alpha = 0.1,
             shape = "★") + 
  theme_bw()

ggplot(data = iris,
       aes(x = Sepal.Length,
           y = Sepal.Width,
           color = Species)) + 
  geom_point(size = 3) + 
  labs(color = "Legend",
       title = "Plot",
       subtitle = "Title-sub") + 
  theme(panel.grid.minor = element_blank())


df = as.data.frame(diamonds)
ggplot(data = df,
       aes(x = cut, y = price,
           color = cut)) + 
  geom_boxplot(fill = "#AAFFAA") + 
  theme_bw() + 
  theme(legend.position = "none") + 
  coord_flip()

ggplot(data = df,
       aes(x = price, 
           fill = after_stat(count))) + 
  geom_histogram(bins = 10)

set.seed(234)
df_s = data.frame(xx = 1:10,
                  yy = sample(1:10, 10))
ggplot(data = df_s,
       aes(x = xx, y = yy)) + 
  geom_point(size = 5, color = "red") + 
  geom_line(linewidth = 2)
ggplot(data = df_s,
       aes(x = xx, y = yy)) + 
  geom_line(linewidth = 2) + 
  geom_point(size = 5, color = "red")

set.seed(123)
df_line = data.frame(xx = rep(1:20, 2),
                     yy = sample(1:10, 40, 
                                 replace = TRUE),
                     group = rep(c("A", "B"), 20))

ggplot(data = df_line,
       aes(x = xx, y = yy, group = group)) + 
  geom_line()
ggplot(data = df_line,
       aes(x = xx, y = yy, 
           group = group, color = group)) + 
  geom_line() + 
  theme(legend.position = "bottom")

df_window = data.frame(xmin = c(0, 5),
                       xmax = c(3, 8),
                       ymin = 0,
                       ymax = 10)
df = data.frame(xx = 0:10,
                yy = c(3, 10, 2, 8, 6, 9, 1, 6, 6, 4, 3))
ggplot() + 
  geom_rect(data = df_window,
            aes(xmin = xmin, xmax = xmax,
                ymin = ymin, ymax = ymax),
            fill = "red", alpha = 0.3) + 
  geom_line(data = df,
            aes(x = xx, y = yy), 
            linewidth = 1.5) + 
  scale_y_continuous(expand = c(0, 0)) +
  theme_bw()

df = as.data.frame(diamonds)

install.packages("patchwork")
library("patchwork")
library("ggplot2")
gg1 = qplot(1:10, 1:10, color = "red")
gg2 = qplot(1:10, 1:10, color = "blue")
gg1 + gg2
gg1 / gg2












