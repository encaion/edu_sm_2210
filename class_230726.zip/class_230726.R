
# 1. 시작하기 ####
1 + 1
library("data.table")

# 주석(comment)
# <-- 여기까지 했음 ㅋㅋ ####
# 해결이 되지 않음.

?head


data("iris")
iris[150, ]
iris[nrow(iris), ]

1234562341234567812345678
TRUE
FALSE
TRUE + FALSE
TRUE + TRUE

letters

(1 + 0.01)^200
(1 + 0.01) ** 200

TRUE
!TRUE
!FALSE
!c(TRUE, FALSE)


library("rvest")
url = "https://search.naver.com/search.naver?where=news&ie=utf8&sm=nws_hty&query=%EC%97%90%EC%BD%94%ED%94%84%EB%A1%9C"

text = read_html(url, encoding = "UTF-8")
text %>% 
  html_nodes("div.news_info") %>% 
  html_text() -> text_parsed
# 크롤링(crawling)
?html_nodes


1:5
6:-5
seq(1, 3)
seq(1, 3, 1)
seq(from = 1, to = 3)
seq(from = 1, to = 3, by = 1)

rep(1:3, 5)
# rep(5, 1:3)
rep(x = 1:3, times = 5)
rep(times = 5, x = 1:3)
?rep

seq(from = 1, to = 3, length.out = 9)

c(1, 2, 3)
c(1, 2, "A") # 한가지 종류의 원소만 있을 수 있음
c("A", "B", "C")
# 원소 3, 4, 5를 c() 함수로 묶어
# aa 객체에 저장(할당)한다.
aa = c(3, 4, 5)
aa
aa[1]
aa[c(1, 3)]
aa[-1] # 첫 번째 원소를 제외하고~
c(99, aa)
bb = aa
bb
bb + 100
bb * 2

data.frame(aa = 1:3,
           bb = letters[1:3])
data.frame(aa = 1:4,
           bb = letters[1:3])
df = data.frame(aa = 1:3,
                bb = letters[1:3])
df
head(df, 1)
tail(df, 1)
df$aa # df 객체의 "aa" 변수.
df[, "aa"]

df$new1 = 100
df[, "new2"] = 200
df

colnames(df) = c("A", "B", "C", "D")
df

colnames(df)[1] = c("col1")
df

colnames(df)

# install.packages("beepr")
library("beepr")
beep(2)
beepr::beep(2)

getwd()

list.files()

aws = read.delim("AWS_sample.txt", sep = "#")
head(aws)

aws = read.csv("AWS_sample.txt", sep = "#")  
head(aws)

# install.packages("data.table")
library("data.table")
df_bike = fread("bike.csv")
head(df_bike, 2)

# install.packages("readxl")
library("readxl")
df_iris = read_excel("iris_xlsx.xlsx")
head(df_iris, 2)

df = read.csv("국가철도공단_서울메트로_주소데이터_20201123.csv", 
              fileEncoding = "CP949")
head(df, 2)


df = read.csv("temp_sensor.csv")
head(df, 2)
tail(df, 2)
summary(df)

nrow(df) # number of rows
ncol(df)

aws = read.csv("AWS_sample.txt", sep = "#")
head(aws)
tail(aws)
aws[1, ] # df[ row , column ]
aws[1:3, ] 
aws[1:3, 1:2]
aws[1:3, c("TM", "TA")]
str(aws)
summary(aws)
nrow(aws)
ncol(aws)
colnames(aws)
aws_sub = aws[, 1:4]
head(aws_sub)

df_dia = read.csv("diamonds.csv")
head(df_dia, 2)
df_dia["price_p_c"] = df_dia$price / df_dia$carat
head(df_dia, 2)

max(df_dia$price)
min(df_dia$price)     
max(df_dia$carat)
min(df_dia$carat)
sd(df_dia$price) # 표준편차
table(df_dia$cut) # counting
prop.table(table(df_dia$cut))
prop.table(table(df_dia$cut)) * 100
round(prop.table(table(df_dia$cut)) * 100, 2)

vec_count = as.numeric(table(df_dia$cut))
vec_prop = as.numeric(prop.table(table(df_dia$cut)))
df_dia_cut = data.frame(type = unique(df_dia$cut),
                        count = vec_count,
                        prop = vec_prop)
df_dia_cut[, "prop_100"] = round(df_dia_cut$prop * 100, 2)
df_dia_cut
write.csv(df_dia_cut, "dia_cut_1.csv")
write.csv(df_dia_cut, "dia_cut_2.csv", row.names = FALSE)
?write.csv


df_dia[, "is_ideal"] = ifelse(df_dia$cut == "Ideal",
                              yes = 1, no = 0)
table(df_dia$cut, df_dia$is_ideal)
head(df_dia)

aa = c(2, 4, 6, 8)
aa[c(1, 3)]
aa[c(TRUE, FALSE, FALSE, FALSE)]
aa > 7
aa[aa > 7]
sum(aa > 7) # 7보다 큰 원소는 몇개인가?

df = data.frame(aa = 1:3,
                bb = c("a", "b", "c"))
df[c(1, 3), ]
df[c(TRUE, TRUE, FALSE), ]
df[df$aa != 2, ]
df[(df$aa == 3) | (df$bb == "b"), ]

df = airquality
df_sub = df[1:5, ]
df[df$Day == 1, ]
df[df$Day != 1, ]
df[df$Day <= 2, ]
df[(df$Day == 1) & (df$Day == 2), ]
df[(df$Day == 1) | (df$Day == 2), ]
df[df$Day %in% c(1, 3), ]

`+`(1, 3)
1 + 3
?`%in%`

df[!(df$Day %in% c(1, 3)), ]
# !는 TRUE/FALSE 를 반전시키기 때문에
# 뒤에서 선언한 조건의 반전 조건을
# 쓰는 것과 같다.

# Q. 데이터가 기록된 월은?
unique(df$Month)

# Q. 몇개월치 데이터가 있는가?
length(unique(df$Month))
length(c(2, 4, 6)) # 원소의 개수

df_dia = read.csv("diamonds.csv")
head(df_dia, 2)

table(df_dia$cut, df_dia$clarity)
condi_1 = df_dia$cut == "Good"
condi_2 = df_dia$clarity == "I1"
df_dia_sub = df_dia[condi_1 & condi_2, ]
nrow(df_dia_sub)

df_sub = read.csv("seoul_subway.csv")
nrow(unique(df_sub[, 2:3]))
length(unique(df_sub$역명))

# Q. 1호선. 역별 승차총승객수의 합산.
df_sub_l1 = df_sub[df_sub$노선명 == "1호선", ]
df_sub_l1_agg = aggregate(data = df_sub_l1,
                          승차총승객수 ~ 역명,
                          FUN = "sum")
df_sub_l1_agg

