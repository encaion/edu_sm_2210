#### .=== 지도학습 === ####
#### [k-NN] ####

library("caret") # k-NN, 정규화(Normalization)
library("Metrics") # 모델 평가
library("caTools") # holdout test(train test split)
library("fastDummies") # One Hot Encoding

# 1) 데이터 읽어오기
# 2) 데이터 파악하기(일단 생략)
# 3) 이상치/결측치 파악 및 처리(일단 생략)
# 4) 데이터 통합(일단 생략)
# 5) 파생변수 생성(매우 중요하나 생략)
# 6) One Hot Encoding
# 7) holdout test(학습/평가 데이터 분리)
# 8) 정규화(필요시)
# 9) 모델 학습(데이터 특성, 종속변수 고려)
# 10) 모델 평가
# 11) 전체 결과 검토

#### 1) 데이터 읽어오기 ####
df = read.csv("diamonds.csv")
df_sub = df[, -c(2, 4)]

#### 2) One Hot Encoding ####
df_dum = dummy_cols(df_sub, select_columns = "color",
                    remove_selected_columns = TRUE,
                    remove_first_dummy = TRUE)

#### 3) Holdout test ####
# train:test = 7:3
set.seed(123)
idx_train = sample.split(df_dum$price, SplitRatio = 0.7)
head(idx_train)

df_train = df_dum[ idx_train, ]
df_test  = df_dum[!idx_train, ]
nrow(df_train) # 38477
nrow(df_test) # 15463

#### 4) 정규화 ####
y_train = df_train$price
y_test  = df_test$price

model_nor = preProcess(df_train[, -4], # price 제외
                       method = "range") # 정규화를 위한 정보 추출(학습)
model_nor$ranges
df_train_nor = predict(model_nor, df_train[, -4]) # 정규화(train)
df_test_nor  = predict(model_nor,  df_test[, -4]) # 정규화(test)
head(df_train_nor, 2)

#### 5) 모델 학습 ####
model_knn = knnreg(x = df_train_nor, y = y_train, k = 11) # 모델 생성
pred_knn = predict(model_knn, df_test_nor) # test set 기반 예측값 생산
head(pred_knn) # 예측값 확인

#### 6) 모델 평가 ####
df_pred = data.frame(y_true = y_test,
                     y_pred = pred_knn)
df_pred[, "error"] = df_pred$y_true - df_pred$y_pred
head(df_pred, 3)
quantile(df_pred$error) # 최소값, Q1, Q2(중앙값), Q3, 최대값

rmse(actual = df_pred$y_true, predicted = df_pred$y_pred) # RMSE
mape(actual = df_pred$y_true, predicted = df_pred$y_pred) # MAPE
# 0.1856

#### [Decision Tree] ####
# install.packages("rpart")
library("rpart")

df = iris
colnames(df)[1:4] = c("SL", "SW", "PL", "PW")
head(df, 2)

# ifelse(조건, 조건이 TRUE 일 때 반환값, 조건이 FALSE 일 때 반환값)
df[, "is_setosa"] = ifelse(df$Species == "setosa", 1, 0)
head(df, 2)

table(df$Species, df$is_setosa)
table(df[, c("Species", "is_setosa")])

set.seed(123)
idx_train = sample.split(Y = df$is_setosa, SplitRatio = 0.7)
df_train = df[ idx_train, ]
df_test  = df[!idx_train, ] # !는 TRUE/FALSE 반전
head(df_train)

TRUE
FALSE
TRUE + FALSE
sum(c(TRUE, TRUE, FALSE))
!c(TRUE, TRUE, FALSE)

head(df_train, 2)
df_train = df_train[, c(6, 1:4)]
head(df_train, 2)
DF2formula(df_train) # 첫 번째 변수를 종속변수로 하는 formula 생성
# 종속변수 ~ 독립변수1 + 독립변수2 + ...
# var1 ~ . <--  formula에서 마침표는 선언된 종속변수를 제외한 나머지 모든 변수
model_dt = rpart(formula = is_setosa ~ . , data = df_train)
model_dt

pred_dt = predict(model_dt, newdata = df_test)
head(pred_dt)

table(df_test$is_setosa, pred_dt)
accuracy(actual = df_test$is_setosa, predicted = pred_dt)

library("ggplot2")
ggplot(data = df,
       aes(x = PL, y = PW, 
           color = Species)) + 
  geom_point(size = 4, alpha = 0.4) + 
  geom_vline(xintercept = 2.45, 
             size = 1.5,
             color = "#000000")

# install.packages("rpart.plot")
library("rpart.plot")
rpart.plot(model_dt)

#### .=== 비지도학습 === ####
#### [k-means] ####
head(df, 2)

model_km = kmeans(df[, 1:4], centers = 3)
model_km
str(model_km) # 객체 구조.
model_km$centers
model_km$cluster

df[, "cluster"] = model_km$cluster
head(df)

aggregate(data = df[, c(1:4, 7)], 
          . ~ cluster, FUN = "mean")

#### [h-clust] ####
df = iris
colnames(df)[1:4] = c("SL", "SW", "PL", "PW")
head(df, 2)

model_hc = hclust(dist(df[, 1:4]))
plot(model_hc)

# install.packages("ggdendro")
library("ggdendro")
ggdendrogram(model_hc) + 
  geom_hline(yintercept = 5,
             color = "#FF0000") + 
  scale_y_continuous(breaks = 0:7)

result_hc = cutree(model_hc, k = 3) # 3개 군집으로 분할.
df[, "cluster"] = result_hc
head(df, 2)

aggregate(data = df[, -5], 
          . ~ cluster, FUN = "mean")

#### .=== 승하차 데이터 === ####
#### [ver. 1] ####
library("data.table")
df = fread("data/data_sm_220101_220630_7k.csv",
           data.table = FALSE)
head(df, 2)
# install.packages("bit64")
# install.packages("readxl") # X L
library("readxl")
df_colnm = read_excel("data/컬럼_정의서.xlsx")
df_colnm$column_name

colnames(df) = df_colnm$column_name
head(df, 2)

library("lubridate")
df[, "USE_DTIME"] = as_datetime(as.character(df$USE_DTIME))
df[, "RIDE_DTIME"] = as_datetime(as.character(df$RIDE_DTIME))
df[, "RECEIVING_DTIME"] = as_datetime(as.character(df$RECEIVING_DTIME))
head(df, 2)

length(unique(df$EXTR_STA_NO))
unique(df$EQP_CLASS_CD) # 장비 구분 코드
unique(df$TRCARD_CLASS_CD)
unique(df$TRCARD_USER_CLASS_CD)
sum(is.na(df$RECEIVING_DTIME))

df_sub = df[, c("USE_DTIME", "EXTR_STA_NO", "TRCARD_NO",
                "RIDE_ALIGHT_CLASS_CD", "RIDE_STA_NO", "RIDE_DTIME")]
colnames(df_sub) = tolower(colnames(df_sub))
colnames(df_sub)[c(2, 4, 5)] = c("stn_out", "ride_cd", "stn_in")
head(df_sub, 2)
# fwrite(df_sub, "data/data_sm_220101_220630_7k_ver2.csv")

#### [ver. 2] ####
library("data.table")
library("lubridate")
df = fread("data/data_sm_220101_220630_7k_ver2.csv",
           data.table = FALSE)
head(df, 2)
unique(df$ride_cd)
# R: 승차, A: 하차

ls_card = unique(df$trcard_no)
head(ls_card)

df_sub = df[df$trcard_no == ls_card[1], -3]
head(df_sub)

table(df_sub$ride_cd)
round(prop.table(table(df_sub$ride_cd)) * 100, 2)

length(ls_card)

head(df, 2)
df[, "cnt"] = 1
df_agg = aggregate(data = df, cnt ~ trcard_no + ride_cd, 
                   FUN = "sum")
head(df_agg, 3)

library("reshape2")
df_agg_cast = dcast(data = df_agg, 
                    trcard_no ~ ride_cd, value.var = "cnt")
head(df_agg_cast)

df = df[df$ride_cd == "A", ]
head(df, 2)

df[, "r_wday"] = wday(df$ride_dtime, week_start = 1)
df_wday = df[df$r_wday <= 5, ] # 월 ~ 금
df_wday[, "r_hour"] = hour(df_wday$ride_dtime)
head(df_wday, 2)

df_wday_agg = aggregate(data = df_wday, 
                        cnt ~ trcard_no + r_hour,
                        FUN = "sum")
head(df_wday_agg, 3)

df_wday_agg_cast = dcast(data = df_wday_agg,
                         trcard_no ~ r_hour,
                         value.var = "cnt", fill = 0)
head(df_wday_agg_cast, 2)
colnames(df_wday_agg_cast)[-1] = paste0("H", 
                                        sprintf(fmt = "%02d",
                                                as.numeric(colnames(df_wday_agg_cast)[-1])))
head(df_wday_agg_cast, 2)

sapply(df_wday_agg_cast[, -1], FUN = "max")

udf_mm = function(x){
  (x - min(x)) / (max(x) - min(x))
}

aa = apply(df_wday_agg_cast[1:3, -1], MARGIN = 1, FUN = udf_mm)
round(t(aa), 2)

df_cast = as.data.frame(t(apply(df_wday_agg_cast[, -1], 
                                MARGIN = 1, FUN = udf_mm)))
head(df_cast, 2)

df_cast = cbind(trcard_no = df_wday_agg_cast$trcard_no,
                df_cast)
head(df_cast, 2)

model_k6 = kmeans(df_cast[, -1], centers = 6)
round(model_k6$centers * 100, 1)
