library("lubridate")

base_folder = "Item_19274_DB"
dir.create(base_folder, showWarnings = FALSE)

for(n in 1:100){
  # n = 1
  dir.create(path = paste0(base_folder, "/", as.character(as.Date(Sys.time()) - n)), 
             showWarnings = FALSE)
}

dir_list = list.dirs(path = base_folder,
                     full.names = TRUE, recursive = FALSE)

for(n in 1:length(dir_list)){
  # n = 1
  
  set.seed(n)
  random_number = sample(3:10, 1)
  sample_df = data.frame(aa = 1:random_number,
                         bb = runif(random_number))
  
  file_name_1 = paste0("POS_", sample(100:299, 1), ".csv")
  file_name_2 = paste0("POS_Backup_", sample(100:299, 1), ".csv")
  
  write.csv(sample_df, 
            paste0(dir_list[n], "/", file_name_1),
            row.names = FALSE)
  write.csv(sample_df, 
            paste0(dir_list[n], "/", file_name_2),
            row.names = FALSE)
  
  sample_df = data.frame(aa = 1:random_number,
                         bb = sample(0:1, replace = TRUE, size = random_number))
  
  file_name_3 = paste0("Item_promo_", sample(100:299, 1), ".csv")
  write.csv(sample_df, 
            paste0(dir_list[n], "/", file_name_3),
            row.names = FALSE)
}

